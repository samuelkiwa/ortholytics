#!/usr/local/bin/perl
# pipeline_speedometer.pl
#
# Cared for by Albert Vilella <>
#
# Copyright Albert Vilella
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code

=head1 NAME

pipeline_speedometer.pl - DESCRIPTION 

=head1 SYNOPSIS

perl pipeline_speedometer.pl \
-i /ecs2/work2/avilella/hive/avilella_compara_homology_40/avilella_compara_homology_40.beehive.out 


=head1 DESCRIPTION

This simple script reads from a beekeeper-loop stdout and does some
calculations about how the pipeline is doing in terms of a speedometer
or tachometer

=head1 AUTHOR - Albert Vilella

Email 

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=cut


# Let the code begin...

use strict;
use Getopt::Long;

my ($inputfile,$lines);

$lines = 10000;

GetOptions(
	   'i|input|inputfile:s' => \$inputfile,
           'l:s' => \$lines,
          );

open (TAILINFILE,"tail -n $lines -f $inputfile |") or die "$!";
#open (TAILINFILE,"$inputfile") or die "$!";
my $last_cpu_hrs = 0;
my $sleep = 2;
while (<TAILINFILE>) {
  if ($_ =~ /\<\s+(\S+)\s+CPU_hrs/) {
    my $cpu_hrs = $1;
    my $speed = sprintf("%03.02f",($last_cpu_hrs - $cpu_hrs)*(60/$sleep));
    my $time_to_destination;
    eval { $time_to_destination = $cpu_hrs / $speed; }; $time_to_destination = 0 if $@;
    $time_to_destination = sprintf("%03.02f",$time_to_destination);
    print "speed = $speed (CPU_hrs/hr), tofinish = $time_to_destination (hours)\n" unless (0 == $last_cpu_hrs);
    $last_cpu_hrs = $cpu_hrs;
  }
}

1;
