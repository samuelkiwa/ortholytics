echo '========= small =========='
bjobs -u all -q small|awk '{print $2,$3}'|sort|grep RUN|uniq -c
echo '========== test =========='
bjobs -u all -q test|awk '{print $2,$3}'|sort|grep RUN|uniq -c
echo '========== long =========='
bjobs -u all -q long|awk '{print $2,$3}'|sort|grep RUN|uniq -c
echo '======== normal =========='
bjobs -u all -q normal|awk '{print $2,$3}'|sort|grep RUN|uniq -c