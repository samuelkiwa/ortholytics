#!/usr/local/bin/perl -w

##############################################################################
#
#  PROGRAM monitor_lsf
#
#  AUTHOR Javier Herrero
#
##############################################################################
#
#  Copyright (c) 2005, Javier Herrero. All Rights Reserved.
#
#  This program is free software; you can redistribute it and/or
#  modify it under the same terms as Perl.
#
##############################################################################

my $print_header = 0;
if (@ARGV and $ARGV[0]) {
  if (!-e $ARGV[0] or !-s $ARGV[0]) {
    $print_header = 1;
  }
  open(FILE, ">>$ARGV[0]") or die();
  select(FILE);
  $| = 0;
} else {
    $print_header = 1;
}
if ($print_header) {
  #print "#   TIME(s)  ok full busy excl wind unav unre  lim  adm lock Date......\n"; 
}
while(1) {
  my @bjobs = qx"bjobs";
  my $status;

  foreach my $line (@bjobs) {
    #JOBID   USER    STAT  QUEUE      FROM_HOST   EXEC_HOST   JOB_NAME   SUBMIT_TIME
    next if $line =~ /^JOBID/;
    $line =~ /(\S+).+\s+(\S+)\s+(\S+)\s+(\S+)$/;
    $status->{$1}->{_day} = $3;
    $status->{$1}->{_month} = $2;
    $status->{$1}->{_time} = $4;
  }
  my $date = qx"date";
  $date =~ /\S+\s+(\S+)\s+(\S+)\s+(\S+)\s+\S+\s+\S+\s+/;

  foreach my $job (keys %{$status}) {
    1;
  }
  #print " ", scalar(localtime(time)), "\n";
  sleep(3600);
}
