#!/bin/sh

# This is an example LSF job wrapper script with all of the following
# features:

# 1) Handles job arrays
# 2) Doesn't use NFS for copying result or input files
# 3) Places output files into an evenly spread hash directory structure
# 4) Keeps file counts down by only copying output files if they contain
#    any data
# 5) Cleans up temporary files
# 6) Exits with the correct exit code from the real job itself

# Work out the output hash directory
destdir="/some/directory/of/your/choosing"
destmachine=ecs2a # The machine hosting $destdir
outfile="mow.$LSB_JOBID.$LSB_JOBINDEX"
outdir=$HOME/`echo -n $outfile | md5sum | cut -c1-6 | sed 's:\(..\):\1/:g'`

# Create the directory if it doesn't already exist.  This uses NFS, but
# it's not too painful.  Bomb out if it doesn't work.
mkdir -p "$outdir" || exit 1

# Create some variables with unique temporary filenames.
tmpoutfile=/tmp/$USER.$LSB_JOBID.$LSB_JOBINDEX.$$.tmp
tmperrfile=$tmpoutfile.err
outfile=$destmachine:$outdir$file
errfile=$outfile.err

# Run the job, storing the output on the execution host
/usr/local/bin/mow $LSB_JOBINDEX > $tmpoutfile 2> $tmperrfile

# Store the exit code to be used later as the real exit code of the
# job
status=$?

if [ $status -eq 0 ]; then
    # Job succeeded
    # Copy the output back to the file server, if it has non-zero
    # size
    if [ -s $tmpoutfile ]; then
        lsrcp $tmpoutfile $outfile
    fi
fi

# Copy the errors file, if it's there
if [ -s $tmperrfile ]; then
    lsrcp $tmperrfile $errfile
fi

# Clean up the temporary files
rm -f $tmpoutfile $tmperrfile

# Return the real exit status of the job itself
exit $status
