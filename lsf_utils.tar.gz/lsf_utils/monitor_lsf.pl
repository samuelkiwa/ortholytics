#!/usr/local/bin/perl -w

##############################################################################
#
#  PROGRAM monitor_lsf
#
#  AUTHOR Javier Herrero
#
##############################################################################
#
#  Copyright (c) 2005, Javier Herrero. All Rights Reserved.
#
#  This program is free software; you can redistribute it and/or
#  modify it under the same terms as Perl.
#
##############################################################################

my $print_header = 0;
if (@ARGV and $ARGV[0]) {
  if (!-e $ARGV[0] or !-s $ARGV[0]) {
    $print_header = 1;
  }
  open(FILE, ">>$ARGV[0]") or die();
  select(FILE);
  $| = 0;
} else {
    $print_header = 1;
}
if ($print_header) {
  print "#   TIME(s)  ok full busy excl wind unav unre  lim  adm lock Date......\n"; 
}
while(1) {
  my @bhosts = qx"bhosts -w";
  my $status;

  foreach my $line (@bhosts) {
    my ($this_status) = $line =~ /\S+\s+(\S+)/;
    $status->{$this_status}++;
  }

  print time();
  foreach my $this_status ("ok", "closed_Full", "closed_Busy", "closed_Excl",
      "closed_Wind", "unavail", "unreach", "closed_LIM", "closed_Adm",
      "closed_Lock") {
    printf " %4d", ($status->{$this_status} or 0);
  }
  print " ", scalar(localtime(time)), "\n";
  sleep(3600);
}
