#!/usr/local/ensembl/bin/perl
use strict;

print "    lsf_fairshare,  jobs, user\n";
open (TAILINFILE,"bqueues -l |") or die "$!";
#open (TAILINFILE,"$inputfile") or die "$!";

my $in_fairshare = 0;
my $sleep = 2;
my ($user,$shares,$priority,$started,$reserved,$cpu_time,$run_time);
my %active_users;
while (<TAILINFILE>) {
  next if $in_fairshare == -1;
  #USER/GROUP   SHARES  PRIORITY  STARTED  RESERVED  CPU_TIME  RUN_TIME
  if ($_ =~ /\s*(\S+)\s+(\S+)\s+\s+(\S+)\s+(\S+)\s+(\S+)\s+CPU_TIME\s+RUN_TIME\n/) {
    $in_fairshare = 1;
    next;
  } elsif (1 == $in_fairshare && $_ =~ /\s*(\S+)\s+(\S+)\s+\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\n/) {
    next if (0 == $4);
    $active_users{$1}{'_user'} =      $1;
    $active_users{$1}{'_shares'} =    $2;
    $active_users{$1}{'_priority'} =  $3;
    $active_users{$1}{'_started'} =   $4;
    $active_users{$1}{'_reserved'} =  $5;
    $active_users{$1}{'_cpu_time'} =  $6;
    $active_users{$1}{'_run_time)'} = $7;
  } elsif (1 == $in_fairshare && $_ =~ /\n/) {
    1;
    $in_fairshare = -1;
  }
}

my $output_string = "";
my @output;

foreach my $user (keys %active_users) {
  my $dynamic_priority;
  eval {$dynamic_priority = ($active_users{$user}{'_shares'} / ((($active_users{$user}{'_cpu_time'})*0.7) + (($active_users{$user}{'_run_time'})*0.7) + (1 + $active_users{$1}{'_started'})*3 ));};
  $dynamic_priority = 0 if $@;
  $active_users{$user}{_fairshare} = sprintf ("%2.15f", $dynamic_priority);
  push @output, sprintf ("%2.15f, %05d, %s\n", $dynamic_priority, $active_users{$user}{_started}, $user);

}
foreach my $elem (sort {$b <=> $a} @output) {  $output_string .= $elem;}
print "$output_string\n";

1;
