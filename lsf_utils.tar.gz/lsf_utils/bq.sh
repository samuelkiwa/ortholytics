#!/bin/sh
bqueues;bqueues | awk '{ sum += $10; print sum; }' | tail -n 1 | awk '{print "Used CPUs      = " $1}'
